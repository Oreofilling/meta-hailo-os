import time
from abc import abstractmethod, ABC
from pyftdi.ftdi import Ftdi
from pyftdi.eeprom import FtdiEeprom
from pyftdi.gpio import GpioAsyncController

class GPIOInst():
    I2C_BUS = 1
    SPI_BUS = 2

    def __init__(self, ftdi_port):
        self.FTDI_PORT = ftdi_port
        self.FTDI_URL = f"ftdi://ftdi:4232h/{self.FTDI_PORT}"
        self.gpio = GpioAsyncController()
        self.gpio.configure(self.FTDI_URL, direction=0xF0, frequency=1e3)

    def set_pin(self, pin_number, value):
        current_output = self.gpio.read()
        new_output = current_output & ~(1 << pin_number) | (value << pin_number)
        self.gpio.write(new_output)

    def get_pin(self, pin_number):
        current_output = self.gpio.read()
        return (current_output >> pin_number) & 1

class PowerManagerFtdi(ABC):
    SHORT_PRESS_TIME = 0.5
    LONG_PRESS_TIME = 3
    RESET_PRESS_TIME = 2
    WAIT_AFTER_RELEASE = 2

    @abstractmethod
    def reset_h15():
        pass

class DirectConnectPowerManagerFtdi(PowerManagerFtdi):
    I2C_BUS = 1
    # Pin number
    RESET_PIN = 0
    POWER_ON_OFF_PIN = 1
    BOOT_STRAP_PIN = 2
    MUX_SEL_PIN = 3  # 0-DB, 1- FTDI on board

    BOOT_FROM_UART_H15 = 1
    BOOT_FROM_NOT_UART_H15 = 0

    BOOT_FROM_UART_H15L = 0
    BOOT_FROM_NOT_UART_H15L = 1

    def __init__(self, is_h15l):
        self.ftdi = Ftdi()
        self._is_h15l = is_h15l
        self.set_cbus_functions()

    def close(self):
        self.ftdi.set_cbus_direction(0b1111, 1 << self.MUX_SEL_PIN)
        self.ftdi.set_cbus_gpio(0b0)    # dummy write, to commit the direction change
        self.ftdi.close()

    def open(self):
        self.ftdi.open_from_url(f"ftdi://ftdi:ft230x/{GPIOInst.I2C_BUS}")

    def reset_h15(self):
        self.open()
        self.ftdi.set_cbus_direction(1 << self.RESET_PIN | 1 << self.MUX_SEL_PIN,
                                     1 << self.RESET_PIN | 1 << self.MUX_SEL_PIN)
        self.ftdi.set_cbus_gpio(1 << self.RESET_PIN)
        time.sleep(0.1)
        self.close()

    def set_cbus_functions(self):
        self.open()
        self.eeprom = FtdiEeprom()
        self.eeprom.connect(self.ftdi)
        if self.eeprom.cbus_mask != 0b0111:
            self.eeprom.set_property('cbus_func_0', 'GPIO')
            self.eeprom.set_property('cbus_func_1', 'GPIO')
            self.eeprom.set_property('cbus_func_2', 'GPIO')
            self.eeprom.set_property('cbus_func_3', 'DRIVE1')
            self.eeprom.commit(dry_run=False)                # Commit the changes to the EEPROM
            self.eeprom.reset_device()                       # Execute a USB device reset
            if self.eeprom.cbus_mask != 0b0111:
                self.ftdi.set_cbus_direction(0b1111, 0b1000)
                self.close()
                raise Exception(f'the CBUS pins was not configured correctly. cbus_mask == {self.eeprom.cbus_mask}')
        self.ftdi.set_cbus_direction(0b1111, 0b1000)
        self.close()